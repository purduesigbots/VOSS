#pragma once

namespace ssov {

struct MotionState {
    double pos;
    double vel;
    double acc;
};

}