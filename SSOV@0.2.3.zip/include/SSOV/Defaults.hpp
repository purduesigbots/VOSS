#pragma once

namespace ssov::defaults {
    // default constants
    const double slew = 8;
}